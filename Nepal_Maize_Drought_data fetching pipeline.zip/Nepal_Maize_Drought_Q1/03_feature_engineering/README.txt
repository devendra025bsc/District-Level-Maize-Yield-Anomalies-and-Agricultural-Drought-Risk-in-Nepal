Feature matrices for correlation/ML analysis go here, built from 02_processed_data/. Add 10_build_feature_matrix.py after data recovery (Master Prompt Section 10).
