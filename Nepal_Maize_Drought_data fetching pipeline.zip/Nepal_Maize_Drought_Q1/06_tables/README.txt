Manuscript Tables 1-12 go here. Table 3 (temporal coverage matrix) is produced by 08_build_temporal_coverage_matrix.py.
