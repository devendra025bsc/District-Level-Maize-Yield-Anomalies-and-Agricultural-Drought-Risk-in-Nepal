Regenerated Figures 1-15 (vector PDF/SVG + publication PNG) go here. qc/ subfolder is populated by 09_data_quality_checks.py.
