Revised manuscript drafts go here once the analysis in 04_analysis/ is finalised on real data.
